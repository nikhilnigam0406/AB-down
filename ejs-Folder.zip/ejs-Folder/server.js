const express = require('express');
const productsData = require('./Model/products');

//create app express instance
const app = express();
const PORT = 3000;

// Set Different Properties
app.set('view engine', 'ejs')
app.set('views', './views')

//Routes
app.get('/', (req, res) => {
    res.render('HomePage', {
        pageTitle: 'Store',
        WelcomeMessage: 'Welcome to my store!',
        products: 'productsData'
    });
});

app.get('/shop', (req, res) => {
    res.render('ShopPage', {
        pageTitle: 'Shop',
        message: 'All items are on sale!',
        products: productsData // Corrected variable name
    });
});

//Listening
app.listen(PORT, () => console.log(`Server is up and running on PORT ${PORT}`));
